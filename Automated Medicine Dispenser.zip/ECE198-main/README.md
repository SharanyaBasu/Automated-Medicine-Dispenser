# ECE198 project - Automatic Medication Dispenser
## Description
This project consists of building an automatic medication dispenser for use in nursing homes. The proejct is done with an NUCLEO-F401RE STM32 board.
